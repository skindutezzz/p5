# Final Project Web template

Please adapt this website template to your needs and add the relevant details accordingly.


## Text Editor

You can use the Brackets editor which you can download from [brackets.io](http://brackets.io/). Brackets allows you to edit individual html, js, css and other text-based files.

Brackets has a live-preview option (⚡) to view changes made to your page immediately – the browser is updated automatically.

